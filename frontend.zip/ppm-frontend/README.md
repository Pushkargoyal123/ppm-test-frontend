# ppm-frontend
Praedico Portfolio Manager - Frontend
