  

 const timeDuration=[
  	{
  		uniq: "D",
  		time: "10 days",
  		number: 10
  	},
  	{
  		uniq: "D",
  		time: "20 days",
  		number: 20
  	},
  	{
  		uniq: "M",
  		time: "1 month",
  		number: 1
  	},
  	{
  		uniq: "M",
  		time: "2 months",
  		number: 2
  	},
  	{
  		uniq: "M",
  		time: "3 months",
  		number: 3
  	},
  	{
  		uniq: "A",
  		time: "ALL",
  		number: null
  	},
  ];

  const niftyStockColumns=[
        { 
          title: 'Company Code', 
          field: 'CompanyCode',  
          cellStyle: { textAlign:"center", color:"blue", fontWeight:"600"}
        },
        { 
          title: 'Company Name', 
          field: 'CompanyName', 
          cellStyle: { textAlign:"center"}, 
          render: rowData=> parseInt(rowData.Variance.substring(1)) > 0 ? <span style={{color:"green"}}>{rowData.CompanyName}</span> : <span style={{color:"red"}}>{rowData.CompanyName}</span> 
        },
        { 
          title: 'Current Price', 
          field: 'CurrentPrice', 
          cellStyle: { textAlign:"center"}, 
          customFilterAndSearch: (term, rowData) => term >= parseInt(rowData.CurrentPrice.substring(1)) 
        },
        { 
          title: 'High Price', 
          field: 'HighPrice',  
          cellStyle: { textAlign:"center"},  
          customFilterAndSearch: (term, rowData) => term >= parseInt(rowData.CurrentPrice.substring(1)) 
        },
        { 
          title: 'Low Price', 
          field: 'LowPrice',  
          cellStyle: { textAlign:"center"} ,  
          customFilterAndSearch: (term, rowData) => term >= parseInt(rowData.CurrentPrice.substring(1))
        },
        { 
          title: 'Variance', 
          field: 'Variance',  
          cellStyle: { textAlign:"center"} 
        },
        { 
          title: 'Signal', 
          field: 'Signal',  
          cellStyle: { textAlign:"center"}, 
          lookup: { "buy": 'BUY', "sell": 'SELL', "strong buy":"STRONG BUY", "strong sell": "STRONG SELL" }, 
          render: rowData=>{if(rowData.Signal==="buy") return <span style={{color:"green", fontWeight:700}}>BUY</span>; else if(rowData.Signal==="sell") return <span style={{color:"red", fontWeight:700}}>SELL</span>; else if(rowData.Signal==="strong buy") return <span style={{color:"green", fontWeight:700}}>STRONG BUY</span>; else if(rowData.Signal==="strong sell") return <span style={{color:"red", fontWeight:700}}>STRONG SELL</span> }  
        },
      ]

const portfolioHistoryColumns=[
                    { 
                        title: 'Trans_ID', 
                        field: 'id' ,
                        cellStyle: { textAlign:"center", backgroundColor:"#e55039",color:"white",  fontWeight:"600"},
                        customFilterAndSearch: (term, rowData) =>term===parseInt(rowData.id)+1000+"",
                        render: rowData=> parseInt(rowData.id) + 1000
                    },
                    { 
                        title: 'Company', 
                        field: 'companyName', 
                        render: rowData=> rowData.companyName + "("+ rowData.companyCode+")" 
                    },
                    { 
                        title: 'Status', 
                        field: 'buyStock', 
                        customFilterAndSearch: (term, rowData) =>term.toUpperCase()==="BUY" ? rowData.buyStock : rowData.sellStock,
                        render: rowData=> rowData.buyStock > 0 ? <span>BUY</span> : <span>SELL</span>,
                    },
                    { 
                        title: 'Stocks', 
                        field: 'buyStock', 
                        render: rowData=> rowData.buyStock > 0 ? <span>{rowData.buyStock}</span> : <span>{rowData.sellStock}</span> 
                    },
                    { 
                        title: 'Date', 
                        field: 'dateTime', 
                        render: rowData=> rowData.dateTime.split(" ")[0]
                    },
                    { 
                        title: 'Time', 
                        field: 'dateTime', 
                        render: rowData=> rowData.dateTime.split(" ")[1] 
                    },
                  ]
  export {
      timeDuration, 
      niftyStockColumns, 
      portfolioHistoryColumns
    }