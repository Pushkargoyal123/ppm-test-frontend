import React, { memo, useState, useCallback } from "react";
import PropTypes from "prop-types";
import {
  AppBar,
  Toolbar,
  Button,
  Hidden,
  IconButton,
  withStyles
} from "@material-ui/core";
import MenuIcon from "@material-ui/icons/Menu";
import HomeIcon from "@material-ui/icons/Home";
import LockOpenIcon from "@material-ui/icons/LockOpen";
import BookIcon from "@material-ui/icons/Book";
import NavigationDrawer from "../../../shared/components/NavigationDrawer";
import { useHistory } from 'react-router-dom';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import InboxIcon from '@material-ui/icons/MoveToInbox';
import DraftsIcon from '@material-ui/icons/Drafts';
import SendIcon from '@material-ui/icons/Send';
import Home from "../../../shared/components/Home";
import ContactUs from "../../../shared/components/ContactUs";
import Stock from "../stocks/Stock";
import AboutUs from "../../../shared/components/AboutUs";
import Portfolio from "../stocks/Portfolio";

const styles = theme => ({
  appBar: {
    boxShadow: theme.shadows[6],
    backgroundColor: theme.palette.common.white
  },
  toolbar: {
    display: "flex",
    justifyContent: "space-between"
  },
  menuButtonText: {
    fontSize: theme.typography.body1.fontSize,
    fontWeight: theme.typography.h6.fontWeight
  },
  brandText: {
    fontFamily: "'Baloo Bhaijaan', cursive",
    fontWeight: 400
  },
  noDecoration: {
    textDecoration: "none !important"
  },
  scroll:{
    overflow:"scroll"
  }
});

const StyledMenu = withStyles({
  paper: {
    border: '1px solid #d3d4d5',
  },
})((props) => (
  <Menu
    elevation={0}
    getContentAnchorEl={null}
    anchorOrigin={{
      vertical: 'bottom',
      horizontal: 'center',
    }}
    transformOrigin={{
      vertical: 'top',
      horizontal: 'center',
    }}
    {...props}
  />
));

const StyledMenuItem = withStyles((theme) => ({
  root: {
    '&:focus': {
      backgroundColor: theme.palette.primary.main,
      '& .MuiListItemIcon-root, & .MuiListItemText-primary': {
        color: theme.palette.common.white,
      },
    },
  },
}))(MenuItem);

function NavBar(props) {

  const {
    classes,
    selectedTab
  } = props;

  const history = useHistory();

   const [component, setComponent]= React.useState(<Home/>)
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);
  const [underlinedButton, setUnderlinedButton]= useState("Home");

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleSelect = () => {
    setAnchorEl(null);
    setComponent(<Stock setComponent={setComponent}/>)
    setUnderlinedButton("Stocks");
  };

  const handleMobileDrawerOpen = useCallback(() => {
    setIsMobileDrawerOpen(true);
  }, [setIsMobileDrawerOpen]);

  const handleMobileDrawerClose = useCallback(() => {
    setIsMobileDrawerOpen(false);
  }, [setIsMobileDrawerOpen]);

  const handleLogOut=()=>{
    localStorage.removeItem("token");
    history.replace({pathname:"/"});
  }

  const menuItems = [
    {
      link: "/c/dashboard",
      name: "Home",
      icon: <HomeIcon className="text-white" />
    },
     {
      menus:"stocks",
      name: "Stocks",
      icon: <LockOpenIcon className="text-white" />
    },
     {
      link:"/portfolio",
      name: "Portfolio",
      icon: <LockOpenIcon className="text-white" />
    },
    {
      link: "/post",
      name: "Blog",
      icon: <BookIcon className="text-white" />
    },
    {
      link:"/aboutus",
      name: "About US",
      icon: <LockOpenIcon className="text-white" />
    },
    {
      link:"/contactus",
      name: "Contact US",
      icon: <LockOpenIcon className="text-white" />
    },
     {
      button:true,
      name: "Log Out",
      icon: <LockOpenIcon className="text-white" />
    },
  ];

  function SetComponent(link, element){
    if(link==="/aboutus"){
      setComponent(<AboutUs/>)
    }
     else if(link==="/contactus"){
      setComponent(<ContactUs/>)
    }
      else if(link==="/portfolio"){
      setComponent(<Portfolio setComponent={setComponent}/>)
    }
     else if(link==="/post"){
      setComponent(<Stock/>)
    }
    else if(link==="/c/dashboard"){
      setComponent(<Home/>)
    }
    else{
      setComponent(<Stock setComponent={setComponent}/>)
    }
    setUnderlinedButton(element.name);
  }

  return (
    <div className={classes.root}>
      <AppBar position="fixed" className={classes.appBar}>
        <Toolbar className={classes.toolbar}>
          <div>
            <img style={{ width: "70px" }} src={`${process.env.PUBLIC_URL}/images/logged_out/pgr_logo.png`} alt="google map" />
          </div>
          <div>
            <Hidden mdUp>
              <IconButton
                className={classes.menuButton}
                onClick={handleMobileDrawerOpen}
                aria-label="Open Navigation"
              >
                <MenuIcon color="primary" />
              </IconButton>
            </Hidden>
            <Hidden smDown>
              {menuItems.map(element => {
                if (element.link) {
                  return (
                      <Button
                        key={element.link}
                        color="secondary"
                        size="large"
                        classes={{ text: classes.menuButtonText }}
                        onClick={()=>SetComponent(element.link, element)}
                        style={underlinedButton===element.name ? {textDecoration:"underline"} : {}}
                      >
                        {element.name}
                      </Button>
                  );
                }
                else if(element.menus){
                   return (<>
                      <Button
                        color="secondary"
                        size="large"
                        onClick={handleClick}
                        key={element.link}
                        classes={{ text: classes.menuButtonText }}
                        style={underlinedButton===element.name ? {textDecoration:"underline"} : {}}
                      >
                        {element.name} &nbsp;
                        <i className="fas fa-caret-down"></i>
                      </Button>
                      <StyledMenu
                        id="customized-menu"
                        anchorEl={anchorEl}
                        keepMounted
                        open={Boolean(anchorEl)}
                        onClose={()=>setAnchorEl(null)}
                      >
                        <StyledMenuItem onClick={handleSelect}>
                          <ListItemIcon>
                            <SendIcon fontSize="small" />
                          </ListItemIcon>
                          <ListItemText primary="Nifty Stocks" />
                        </StyledMenuItem>

                        <StyledMenuItem>
                          <ListItemIcon>
                            <DraftsIcon fontSize="small" />
                          </ListItemIcon>
                          <ListItemText primary="Drafts" />
                        </StyledMenuItem>
                        
                        <StyledMenuItem>
                          <ListItemIcon>
                            <InboxIcon fontSize="small" />
                          </ListItemIcon>
                          <ListItemText primary="Inbox" />
                        </StyledMenuItem>
                      </StyledMenu></>
                  );
                }
                  return (
                      <Button
                      key={element.link}
                        color="secondary"
                        size="large"
                        classes={{ text: classes.menuButtonText }}
                        onClick={handleLogOut}
                      >
                        {element.name}
                      </Button>
                  );
              })}
            </Hidden>
          </div>
        </Toolbar>
      </AppBar>
      <div className="background">{component}</div>
      <NavigationDrawer
        menuItems={menuItems}
        anchor="right"
        open={isMobileDrawerOpen}
        selectedItem={selectedTab}
        onClose={handleMobileDrawerClose}
        setComponent={SetComponent}
        handleLogOut= {handleLogOut}
      />
    </div>
  );
}

NavBar.propTypes = {
  classes: PropTypes.object.isRequired,
  handleMobileDrawerOpen: PropTypes.func,
  handleMobileDrawerClose: PropTypes.func,
  mobileDrawerOpen: PropTypes.bool,
  selectedTab: PropTypes.string,
  openRegisterDialog: PropTypes.func,
  openLoginDialog: PropTypes.func
};

export default withStyles(styles, { withTheme: true })(memo(NavBar));
