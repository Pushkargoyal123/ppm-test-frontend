import React, { memo, useState, useEffect } from "react";
import PropTypes from "prop-types";
import {
  AppBar,
  Toolbar,
  Button,
  Hidden,
  IconButton,
  withStyles
} from "@material-ui/core";
import MenuIcon from "@material-ui/icons/Menu";
import axios from "axios";
import HomeIcon from "@material-ui/icons/Home";
import HowToRegIcon from "@material-ui/icons/HowToReg";
import LockOpenIcon from "@material-ui/icons/LockOpen";
import BookIcon from "@material-ui/icons/Book";
import NavigationDrawer from "../../../shared/components/NavigationDrawer";
import Modal from '@material-ui/core/Modal';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import InputAdornment from '@material-ui/core/InputAdornment';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import TextField from '@material-ui/core/TextField';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import FormLabel from '@material-ui/core/FormLabel';
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import { useHistory } from 'react-router-dom';
import Swal from "sweetalert2";
import Home from "../../../shared/components/Home";
import AboutUs from "../../../shared/components/AboutUs";
import Stock from "../home/Stock";
import ContactUs from "../../../shared/components/ContactUs";
import MemberShip from "../../../shared/components/MemberShip";
import DreamNifty from "../../../shared/components/DreamNifty";
import {postData} from "../../../service/service";
import {toast, ToastContainer} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const styles = theme => ({
  appBar: {
    boxShadow: theme.shadows[6],
    backgroundColor: theme.palette.common.white
  },
  toolbar: {
    display: "flex",
    justifyContent: "space-between"
  },
  menuButtonText: {
    fontSize: theme.typography.body1.fontSize,
    fontWeight: theme.typography.h6.fontWeight
  },
  brandText: {
    fontFamily: "'Baloo Bhaijaan', cursive",
    fontWeight: 400
  },
  noDecoration: {
    textDecoration: "none !important"
  },
  error :{
    textAlign:"left", 
    color:"red", 
    opacity:"0.7", 
    fontSize:"0.7rem"
  }
});

function getModalStyle() {
  const top =50;
  const left = 50;

  return {
    top: `${top}%`,
    left: `${left}%`,
    transform: `translate(-${top}%, -${left}%)`,
     position: 'absolute',
        minWidth: 500,
        maxWidth:600,
        textAlign:"center",
        backgroundColor: "white",
        border: '2px solid grey',
        boxShadow: "0 0 8px 2px black",
        borderRadius:20,
        maxHeight:"100vh",
        overflowX:"scroll",
  };
}


function NavBar(props) {

  const {
    classes,
    openRegisterDialog,
    openLoginDialog,
    handleMobileDrawerOpen,
    handleMobileDrawerClose,
    mobileDrawerOpen,
    selectedTab
  } = props;

  const history = useHistory();

  useEffect(function(){
    const checkAuthentication=async()=>{
      const response = await axios.post("http://localhost:7080/api/user/authenticate",{token:localStorage.getItem("token")} );
      const result = await response.data;
      if(result.success){
        history.replace({pathname:"/c/dashboard"},{});
      }
  }
    checkAuthentication();
  }, [history])

   const [name, setName] = React.useState("");
    const [gender, setGender] = React.useState("");
    const [email, setEmail] = React.useState("");
    const [loginEmail, setLoginEmail] = React.useState("");
    const [whatsappNumber, setWhatsappNumber] = React.useState("");
    const [password, setPassword]= React.useState("");
    const [showPassword, setShowPassword]= React.useState(false);
    const [selectedDate, setSelectedDate] = React.useState(null);
    const [loginPassword, setLoginPassword]= useState("");
    const [serialNumber, setSerialNumber]= useState("");
   const [modalStyle] = React.useState(getModalStyle);
   const [component, setComponent]= React.useState(<Home/>)
  const [open, setOpen] = React.useState(false);
  const [openModal, setOpenModal]= React.useState(false);
  const [body, setBody]= React.useState(false);
  const [nameError, setNameError]= React.useState(false);
  const [genderError, setGenderError]= useState(false);
  const [emailError, setEmailError]= React.useState(false);
  const [whatsappNumberError, setWhatsappNumberError]= React.useState(false);
  const [selectedDateError, setSelectedDateError]= useState(false);
  const [passwordError, setPasswordError]= useState(false);
  const [loginEmailError, setLoginEmailError]= useState(false);
  const [loginPasswordError, setLoginPasswordError]= useState(false);
   const [underlinedButton, setUnderlinedButton]= useState("Home");


      const handleSubmit=async()=>{
            let err=false;

            if(name.trim()===""){
              err=true;
              setNameError(true)
            }
            else{
              setNameError(false)
            }

            if(email.trim()===""){
              err=true;
              setEmailError(true)
            }
            else{
              setEmailError(false)
            }

              if(whatsappNumber.trim()===""){
              err=true;
              setWhatsappNumberError(true)
            }
            else{
              setWhatsappNumberError(false)
            }

            if(!selectedDate){
              err=true;
              setSelectedDateError(true)
            }
            else{
              setSelectedDateError(false)
            }
            if(password.trim()===""){
              err=true;
              setPasswordError(true)
            }
            else{
              setPasswordError(false)
            }
            if(gender===""){
              err=true;
              setGenderError(true)
            }
            else{
              setGenderError(false)
            }

            if(!err){
              var form = { userName: name,dob:selectedDate, gender: gender,email:email,phone:whatsappNumber, password:password };
              const response = await postData("user/registration", form);
              if (response.success) {
                setOpen(false);
                Swal.fire({
                  icon: 'success',
                  title: 'Registration Done',
                  text: 'Login now',
                }).then(
                  function(){
                    setOpen(true);
                    setBody(true)
                    setLoginEmail(email);
                    setLoginPassword(password);
                  })
              }
              else{
                if(response.error.errors){
                  setOpen(false);
                   Swal.fire({
                    icon: 'info',
                    title: 'Already Sign Up',
                    text: "User Already Registered Login Now",
                  }).then(
                    function(){
                      setOpen(true);
                      setBody(true)
                      setLoginEmail(email);
                      setLoginPassword(password);
                    })
                }
                else{
                  toast.error('🦄 '+  response.error.details[0].message ,{

                     position: "top-right",
                      autoClose: 5000,
                      hideProgressBar: true,
                      closeOnClick: false,
                      pauseOnHover: true,
                      draggable: true,
                      progress: undefined,
                      color:"red"
                    });
                  }
              }
            }
  }

    const handleLogin=async()=>{

        let err=false;

            if(loginEmail.trim()===""){
              err=true;
              setLoginEmailError(true)
            }
            else{
              setLoginEmailError(false)
            }

            if(loginPassword.trim()===""){
              err=true;
              setLoginPasswordError(true)
            }
            else{
              setLoginPasswordError(false)
            }
      if(!err){

        let form= {email:loginEmail, password: loginPassword};
         const data= await postData("user/login", form);
       
        if(data.success){
           Swal.fire({
              icon: 'success',
              title: 'Success',
              text: 'Login Successfully',
            })
          localStorage.setItem("token", data.data.token);
          history.replace({pathname:"/c/dashboard"},{data});
        }
        else{
          setOpen(false);
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: data.message,
          })
        }
      }
    }

    const body1 = (
    <div style={modalStyle} >
      <div className="flexBox">
        <span></span>
        <div style={{fontSize:"30px", fontWeight:500}}>Registration Page</div>
        <i style={{fontSize:25, cursor:"pointer"}} onClick={()=>setOpen(false)} class="fas fa-times"></i>
      </div>
       <div style={{ margin: 10 }}>
        <TextField value={name} error={nameError} helperText={nameError ? "*Name Should be Provided": ""}  onChange={(event) => setName(event.target.value)} id="outlined-basic" placeholder="ex. Pushkar Goyal" label="Name" variant="outlined" style={{ width: 350 }} />
      </div>
        
          <FormControl style={{ width: 350 }} component="fieldset">
                <FormLabel style={{ textAlign: "left", color: genderError ? "red": "grey" }} component="legend">Gender</FormLabel>
                <RadioGroup row aria-label="gender"  name="row-radio-buttons-group">
                    <FormControlLabel onChange={(event) => { setGender(event.target.value) }} value="female" control={<Radio />} label="Female" checked={gender==="female"} />
                    <FormControlLabel onChange={(event) => { setGender(event.target.value) }} value="male" control={<Radio />} label="Male" checked={gender==="male"}/>
                </RadioGroup>
                {genderError ? <div className={classes.error}> *Gender Should be Provided</div> : <div></div>}
            </FormControl>

            <div style={{ margin: 10 }}>
              <TextField value={email} error={emailError} helperText={emailError ? "*Email should be provided" : ""} onChange={(event) => { setEmail(event.target.value) }} placeholder="ex. pushkargoyal36@gmail.com" id="outlined-ba" label="Email" type="email" variant="outlined" style={{ width: 350 }} />
            </div>
             <div style={{ margin: 10 }}>
              <TextField value={whatsappNumber} error={whatsappNumberError} helperText={whatsappNumberError ? "*Whatsapp Number should be provided" : ""} onChange={(event) => { setWhatsappNumber(event.target.value) }} placeholder="ex. 7024649556" id="outlined-basi" label="Whatsapp Number" variant="outlined" style={{ width: 350 }} />
            </div>

              <MuiPickersUtilsProvider style={{margin:10}} utils={DateFnsUtils}>
             <KeyboardDatePicker
          disableToolbar
          variant="inline"
          format="MM/dd/yyyy"
          error={selectedDateError}
          helperText={selectedDateError ? "*Date Of Birth Should be Provided" :"date format MM/DD/YYYY"}
          id="date-picker-inline"
          label="Date of birth"
          value={selectedDate}
          style={{width:350}}
          onChange={(date)=>setSelectedDate(date)}
          KeyboardButtonProps={{
            'aria-label': 'change date',
          }}
        />
        </MuiPickersUtilsProvider>
               <FormControl style={{width:350}}>
          <InputLabel >Password</InputLabel>
          <Input
            id="standard-adornment-password"
            error={passwordError}
            type={showPassword ? 'text' : 'password'}
            onChange={(event)=>{setPassword(event.target.value)}}
            value={password}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={()=>setShowPassword(!showPassword)}
                >
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }
          />
          {passwordError ? <div className={classes.error}> *Password should be provided </div> :<div></div>}
        </FormControl>
        <div onClick={()=>setBody(true)} className="links" style={{marginTop:10}}> Login now if already Registered ?</div>
            <div><Button onClick={handleSubmit} color="secondary" style={{ margin: 10, width: 350 }} variant="contained">Submit</Button></div>
    </div>
  );


    const body2 = (
    <div style={modalStyle} >
      <div className="flexBox">
        <span></span>
        <h2 id="simple-modal-title">Login Page</h2>
        <i style={{fontSize:25, cursor:"pointer"}} onClick={()=>setOpen(false)} class="fas fa-times"></i>
      </div>
        <div style={{ margin: 20 }}>
          <TextField value={loginEmail} error={loginEmailError} helperText={loginEmailError ? "*Email should be required" : ""} onChange={(event) => { setLoginEmail(event.target.value) }} placeholder="ex. pushkargoyal36@gmail.com" id="outlined-ba" label="Email" type="email" variant="outlined" style={{ width: 350 }} />
        </div>
        <FormControl style={{width:350}} variant="outlined">
          <InputLabel >Password</InputLabel>
          <Input
            id="standard-adornment-password"
            type={showPassword ? 'text' : 'password'}
            error={loginPasswordError}
            value={loginPassword}
            onChange={(event)=>{setLoginPassword(event.target.value)}}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={()=>setShowPassword(!showPassword)}
                >
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }
          />
          {loginPasswordError ? <div className={classes.error}> *Password should be provided </div> :<div></div>}
        </FormControl>
          <div onClick={()=>setBody(false)} className="links" style={{marginTop:10}}> Register now if not ?</div>
          <div className="links">Forgot Password ? </div>
         <div><Button onClick={handleLogin} color="secondary" style={{ margin: 20, width: 400 }} variant="contained">Login</Button></div>
    </div>
  );

    const body3 =(
      <div style={modalStyle}>
        <div className="flexBox">
          <span></span>
          <h2 id="simple-modal-title">Fetch Certificate</h2>
           <i style={{fontSize:25, cursor:"pointer"}} onClick={()=>setOpenModal(false)} class="fas fa-times"></i>
        </div>
        <div style={{ margin: 20 }}><TextField autoComplete="off" onChange={(event) => { setSerialNumber(event.target.value) }} placeholder="ex. 12345678" id="outlined-ba" label="Serial Number" variant="outlined" style={{ width: 350 }} /></div>
        <div style={{display:"flex", justifyContent:"space-around"}}>
          <Button onClick={()=>alert("You entered "+serialNumber)} color="primary" style={{ margin: 20 }} variant="contained">Submit</Button>
          <Button onClick={()=>setOpenModal(false)} color="primary" style={{ margin: 20 }} variant="contained">Cancil</Button>
        </div>
      </div>
      )

  const handleOpen = (name) => {
    if(name==="Login")
      setBody(true);
    else
      setBody(false)
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const menuItems = [
    {
      link: "/",
      name: "Home",
      icon: <HomeIcon className="text-white" />
    },
     {
      link:"/stocks",
      name: "Stocks",
      icon: <LockOpenIcon className="text-white" />
    },
     {
      link: "/membership",
      name: "MemberShip",
      icon: <BookIcon className="text-white" />
    },
    {
      name: "Fetch-Certificate",
      modal: true,
      icon: <HowToRegIcon className="text-white" />
    },
      {
      link: "/dreamnifty",
      name: "Dream-Nifty",
      icon: <BookIcon className="text-white" />
    },
    {
      link: "/blog",
      name: "Blog",
      icon: <BookIcon className="text-white" />
    },
    {
      link:"/aboutus",
      name: "About US",
      icon: <LockOpenIcon className="text-white" />
    },
    {
      link:"/contactus",
      name: "Contact US",
      icon: <LockOpenIcon className="text-white" />
    },
    {
      name: "Register",
      onClick: openRegisterDialog,
      icon: <HowToRegIcon className="text-white" />
    },
    {
      name: "Login",
      onClick: openLoginDialog,
      icon: <LockOpenIcon className="text-white" />
    }
  ];

  function SetComponent(link, element){
    if(link==="/aboutus"){
      setComponent(<AboutUs/>)
    }
     else if(link==="/contactus"){
      setComponent(<ContactUs/>)
    }
    else if(link==="/membership"){
      setComponent(<MemberShip/>)
    }
    else if(link==="/dreamnifty"){
      setComponent(<DreamNifty/>)
    }
     else if(link==="/stocks"){
      setComponent(<Stock/>)
    }
    else if(link==="/"){
      setComponent(<Home/>)
    }
    setUnderlinedButton(element.name);
  }

  return (
    <div className={classes.root}>
      <AppBar position="fixed" className={classes.appBar}>
        <Toolbar className={classes.toolbar}>
          <div>
            <img style={{ width: "70px" }} src={`${process.env.PUBLIC_URL}/images/logged_out/pgr_logo.png`} alt="google map" />
          </div>
          <div>
            <Hidden mdUp>
              <IconButton
                className={classes.menuButton}
                onClick={handleMobileDrawerOpen}
                aria-label="Open Navigation"
              >
                <MenuIcon color="primary" />
              </IconButton>
            </Hidden>
            <Hidden smDown>
              {menuItems.map(element => {
                if (element.link) {
                  return (
                      <Button
                        key={element.link}
                        color="secondary"
                        size="large"
                        classes={{ text: classes.menuButtonText }}
                        onClick={()=>SetComponent(element.link, element)}
                        style={underlinedButton===element.name ? {textDecoration:"underline"} : {}}
                      >
                        {element.name}
                      </Button>
                  );
                }
                else if(element.modal){
                  return(<span key={element.name}>
                   <Modal
                    open={openModal}
                    onClose={()=>setOpenModal(false)}
                    aria-labelledby="simple-modal-title"
                    aria-describedby="simple-modal-description"
                  >
                    {body3}
                  </Modal>
                  <Button
                        color="secondary"
                        size="large"
                        classes={{ text: classes.menuButtonText }}
                        onClick={()=>setOpenModal(true)}
                        style={underlinedButton===element.name ? {textDecoration:"underline"} : {}}
                      >
                        {element.name}
                    </Button>
                    </span>);
                }
                return (<span key={element.name}>
                  <Modal
                    open={open}
                    onClose={handleClose}
                    aria-labelledby="simple-modal-title"
                    aria-describedby="simple-modal-description"
                  >
                    {body? body2 : body1}
                  </Modal>
                  <Button
                    color="secondary"
                    size="large"
                    onClick={()=>handleOpen(element.name)}
                    classes={{ text: classes.menuButtonText }}
                    style={underlinedButton===element.name ? {textDecoration:"underline"} : {}}
                  >
                    {element.name}
                  </Button>
                  </span>
                );
              })}
            </Hidden>
          </div>
        </Toolbar>
      </AppBar>
      {component}
      <NavigationDrawer
        menuItems={menuItems}
        anchor="right"
        onOpen={handleMobileDrawerOpen}
        open={mobileDrawerOpen}
        selectedItem={selectedTab}
        onClose={handleMobileDrawerClose}
        setComponent={SetComponent}
        handleLogin={handleLogin}
      />
          <ToastContainer
            position="top-right"
            autoClose={5000}
            hideProgressBar={false}
            newestOnTop={false}
            closeOnClick
            rtl={false}
            pauseOnFocusLoss
            draggable
            pauseOnHover
          />
    </div>
  );
}

NavBar.propTypes = {
  classes: PropTypes.object.isRequired,
  handleMobileDrawerOpen: PropTypes.func,
  handleMobileDrawerClose: PropTypes.func,
  mobileDrawerOpen: PropTypes.bool,
  selectedTab: PropTypes.string,
  openRegisterDialog: PropTypes.func.isRequired,
  openLoginDialog: PropTypes.func.isRequired
};

export default withStyles(styles, { withTheme: true })(memo(NavBar));
