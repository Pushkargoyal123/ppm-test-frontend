
const ServerURL="http://localhost:7080/api/";

async function postData(url, body){
	 const response = await fetch(ServerURL + url , { method: "POST", mode: "cors", headers: { "Content-Type": "application/json;charset=utf-8" }, body:JSON.stringify(body)});
     const result = await response.json();
     return result;
}

export {ServerURL, postData};